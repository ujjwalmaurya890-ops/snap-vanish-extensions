/**
 * Snap Vanish — content script.
 *
 * Runs in the call tab. Captures the outgoing video track, runs the snap
 * detector over it, and when a snap is confirmed, replaces the track the
 * peers receive with a composited one (RTCRtpSender.replaceTrack) and mutes
 * the outgoing audio track. Everything is local: this file contains no fetch,
 * no WebSocket and no remote code.
 *
 * Trigger rule (strict on purpose):
 *   visual candidate  = landmark 4 (thumb tip) -> landmark 12 (middle tip)
 *                       distance collapses 45mm -> 12mm within 120ms,
 *                       with landmark 8 and 20 extended and spread,
 *                       wrist angular velocity < 2.2 rad/s,
 *                       hand bbox area delta < 40% (rejects reaching/typing)
 *   audio confirm     = band-passed 2.5-5.5kHz onset, < 90ms transient,
 *                       >= 12dB RMS jump, within +-220ms of the candidate
 *
 * Sound never triggers anything on its own.
 */

const SNAP = {
  TIP_NEAR: 12, // mm, thumb tip <-> middle tip at the click
  TIP_FAR: 45, // mm, before the click
  COLLAPSE_MS: 120,
  MAX_WRIST_OMEGA: 2.2, // rad/s
  MAX_BBOX_DELTA: 0.4,
  AUDIO_WINDOW_MS: 220,
  AUDIO_MIN_DB: 12,
  AUDIO_MAX_TRANSIENT_MS: 90,
  AUDIO_BAND: [2500, 5500],
};

class SnapDetector {
  constructor(sensitivity = 0.62) {
    this.sensitivity = sensitivity;
    this.history = [];
    this.lastAngle = null;
    this.lastAngleAt = 0;
    this.lastBBox = null;
  }

  /** @param {Array<{x:number,y:number,z:number}>} lm 21 hand landmarks, normalised */
  push(lm, now = performance.now()) {
    const d = dist3(lm[4], lm[12]);
    const extended = dist3(lm[8], lm[0]) > dist3(lm[6], lm[0]) * 1.12
      && dist3(lm[20], lm[0]) > dist3(lm[18], lm[0]) * 1.12;
    const spread = dist3(lm[8], lm[20]);

    const bbox = bounding(lm);
    const omega = this.wristAngularVelocity(lm, now);
    const bboxDelta = this.lastBBox
      ? Math.abs(area(bbox) - area(this.lastBBox)) / area(this.lastBBox)
      : 0;
    this.lastBBox = bbox;

    this.history.push({ d, now, extended, spread, omega, bboxDelta });
    if (this.history.length > 24) this.history.shift();

    const far = this.history.find((h) => now - h.now <= SNAP.COLLAPSE_MS && h.d > SNAP.TIP_FAR);
    const near = d < SNAP.TIP_NEAR * (0.6 + this.sensitivity * 0.9);
    if (!far || !near || !extended) return false;
    if (omega > SNAP.MAX_WRIST_OMEGA) return false;
    if (bboxDelta > SNAP.MAX_BBOX_DELTA) return false;

    this.history.length = 0;
    return true;
  }

  wristAngularVelocity(lm, now) {
    const a = Math.atan2(lm[0].y - lm[9].y, lm[0].x - lm[9].x);
    if (this.lastAngle === null) {
      this.lastAngle = a;
      this.lastAngleAt = now;
      return 0;
    }
    const dt = (now - this.lastAngleAt) / 1000 || 0.033;
    let da = a - this.lastAngle;
    if (da > Math.PI) da -= Math.PI * 2;
    if (da < -Math.PI) da += Math.PI * 2;
    this.lastAngle = a;
    this.lastAngleAt = now;
    return Math.abs(da / dt);
  }
}

class AudioConfirmer {
  constructor(stream) {
    this.ctx = new AudioContext();
    const src = this.ctx.createMediaStreamSource(stream);
    const bp = this.ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = (SNAP.AUDIO_BAND[0] + SNAP.AUDIO_BAND[1]) / 2;
    bp.Q.value = 1.1;
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 512;
    this.buf = new Float32Array(this.analyser.fftSize);
    src.connect(bp).connect(this.analyser);
    this.floor = -60;
    this.lastOnset = 0;
    this.baselineAt = performance.now();
  }

  /** @returns {number|null} ms timestamp of a qualifying onset, else null */
  poll(now = performance.now()) {
    this.analyser.getFloatTimeDomainData(this.buf);
    let sum = 0;
    for (let i = 0; i < this.buf.length; i++) sum += this.buf[i] * this.buf[i];
    const rms = Math.sqrt(sum / this.buf.length);
    const db = 20 * Math.log10(rms + 1e-9);

    // adapt to the room: silence floor drifts, the snap must still clear it
    if (db < this.floor + 3) this.floor += (db - this.floor) * 0.02;
    const jump = db - this.floor;
    if (jump < SNAP.AUDIO_MIN_DB) return null;

    const transient = now - this.lastOnset;
    this.lastOnset = now;
    if (transient > SNAP.AUDIO_MAX_TRANSIENT_MS) return null; // too slow: a clack, a voice
    return now;
  }
}

class MatteEngine {
  constructor() {
    this.alpha = null;
  }

  /** Temporal self-segmentation: blend with the previous matte, then median. */
  frame(imageData) {
    const seg = segmentSelfie(imageData); // Float32Array of alphas, same resolution
    if (!this.alpha) this.alpha = seg;
    else {
      for (let i = 0; i < seg.length; i++) this.alpha[i] = this.alpha[i] * 0.85 + seg[i] * 0.15;
    }
    return median3(median3(this.alpha, imageData.width), imageData.width);
  }
}

class VanishController {
  constructor() {
    this.settings = { enabled: true, sensitivity: 62, duration: 1.8, direction: "right", sound: true };
    this.detector = new SnapDetector(0.62);
    this.matte = new MatteEngine();
    this.plate = null;
    this.dust = null;
    this.muted = false;
    this.pendingCandidateAt = 0;
  }

  async start() {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    this.videoTrack = stream.getVideoTracks()[0];
    this.audioTrack = stream.getAudioTracks()[0];
    this.audio = new AudioConfirmer(stream);
    this.capture = new ImageCapture(this.videoTrack);
    this.loop();
  }

  async loop() {
    const frame = await this.capture.grabFrame();
    const now = performance.now();
    const lm = await estimateHands(frame);
    const onset = this.audio.poll(now);

    if (lm && this.detector.push(lm, now)) this.pendingCandidateAt = now;

    // the mic only confirms a visual candidate, never creates one
    const confirmed =
      this.pendingCandidateAt &&
      onset &&
      Math.abs(onset - this.pendingCandidateAt) <= SNAP.AUDIO_WINDOW_MS;

    if (confirmed && this.settings.enabled) {
      this.pendingCandidateAt = 0;
      this.toggle();
    }
    requestAnimationFrame(() => this.loop());
  }

  async toggle() {
    if (!this.dust) {
      const alpha = this.matte.frame(await this.capture.grabFrame());
      this.dust = buildDustScene(await this.capture.grabFrame(), alpha, this.plate);
      this.setMic(true);
    } else {
      this.dust.reverse();
      this.setMic(false);
    }
  }

  /** Mutes the outgoing audio track — and the meeting's own mute button. */
  setMic(muted) {
    this.muted = muted;
    if (this.audioTrack) this.audioTrack.enabled = !muted;
    const btn = document.querySelector('[aria-label*="mute" i], [aria-label*="Mute" i]');
    const pressed = btn?.getAttribute("aria-pressed") === "true";
    if (btn && pressed !== muted) btn.click();
  }

  /** The frame the peers actually see: dust composited over the empty plate. */
  async paint(canvas, t) {
    const ctx = canvas.getContext("2d");
    ctx.drawImage(this.plate, 0, 0, canvas.width, canvas.height);
    this.dust.render(ctx, t, this.settings.direction, this.settings.duration);
    if (this.videoTrack && !this.replaced) {
      this.replaced = canvas.captureStream(30).getVideoTracks()[0];
      for (const pc of peerConnections()) {
        for (const sender of pc.getSenders()) {
          if (sender.track?.kind === "video") await sender.replaceTrack(this.replaced);
        }
      }
    }
  }
}

/* --- small helpers the real build implements against the bundled model --- */
const dist3 = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, (a.z ?? 0) - (b.z ?? 0));
const area = (b) => Math.max(1e-6, (b.x1 - b.x0) * (b.y1 - b.y0));
const bounding = (lm) => ({
  x0: Math.min(...lm.map((p) => p.x)),
  x1: Math.max(...lm.map((p) => p.x)),
  y0: Math.min(...lm.map((p) => p.y)),
  y1: Math.max(...lm.map((p) => p.y)),
});
function median3() { throw new Error("bound to bundled WASM model in the shipped build"); }
function segmentSelfie() { throw new Error("bound to bundled WASM model in the shipped build"); }
function estimateHands() { throw new Error("bound to bundled WASM model in the shipped build"); }
function buildDustScene() { throw new Error("see content/dust-engine.js — 22k particle curl-noise field"); }
function peerConnections() { return []; }

chrome.runtime.onMessage.addListener((msg, _s, respond) => {
  switch (msg?.type) {
    case "SNAP_TOGGLE":
      window.__snapVanish?.toggle();
      respond({ ok: true, muted: window.__snapVanish?.muted });
      break;
    case "MUTE_TOGGLE":
      window.__snapVanish?.setMic(!window.__snapVanish.muted);
      respond({ ok: true, muted: window.__snapVanish?.muted });
      break;
    case "RESET_FRAME":
      window.__snapVanish?.dust?.reverse();
      respond({ ok: true });
      break;
    case "SETTINGS":
      Object.assign(window.__snapVanish.settings, msg.payload);
      respond({ ok: true });
      break;
    case "STATE":
      respond({
        ok: true,
        host: location.host,
        muted: Boolean(window.__snapVanish?.muted),
      });
      break;
    default:
      respond({ ok: false });
  }
  return true;
});

window.__snapVanish = new VanishController();
if (document.readyState === "complete") window.__snapVanish.start().catch(() => {});
else window.addEventListener("load", () => window.__snapVanish.start().catch(() => {}));
