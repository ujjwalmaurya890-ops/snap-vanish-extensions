/**
 * Snap Vanish — service worker.
 *
 * Routes the keyboard commands and popup actions to whichever tab is
 * currently on a call. Nothing here touches the network: there is no fetch
 * in this file, and there is no fetch anywhere else in the bundle.
 */

const CALL_HOSTS = ["meet.google.com", "teams.microsoft.com", "zoom.us"];

const DEFAULTS = {
  enabled: true,
  sensitivity: 62,
  duration: 1.8,
  direction: "right",
  sound: true,
};

async function activeCallTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url) return null;
  const host = new URL(tab.url).hostname;
  return CALL_HOSTS.some((h) => host === h || host.endsWith(`.${h}`)) ? tab : null;
}

async function send(message) {
  const tab = await activeCallTab();
  if (!tab) return { ok: false, reason: "no-call-tab" };
  try {
    return await chrome.tabs.sendMessage(tab.id, message);
  } catch {
    return { ok: false, reason: "content-script-not-ready" };
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.sync.get(null);
  await chrome.storage.sync.set({ ...DEFAULTS, ...stored });
});

chrome.commands.onCommand.addListener((command) => {
  const action = {
    "toggle-snap": "SNAP_TOGGLE",
    "vanish-now": "SNAP_VANISH_NOW",
    "mute-only": "MUTE_TOGGLE",
    "reset-frame": "RESET_FRAME",
  }[command];
  if (action) send({ type: action });
});

chrome.runtime.onMessage.addListener((message, _sender, respond) => {
  if (message?.type === "SNAP_NOW") send({ type: "SNAP_TOGGLE" }).then(respond);
  else if (message?.type === "SETTINGS_CHANGED") send({ type: "SETTINGS", payload: message.payload }).then(respond);
  else if (message?.type === "GET_STATE") send({ type: "STATE" }).then(respond);
  else if (message?.type === "PING") respond({ ok: true, host: "service-worker" });
  return true;
});
