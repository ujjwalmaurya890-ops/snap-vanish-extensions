/* Snap Vanish popup controller — reads/writes chrome.storage.sync and asks
   the service worker to talk to the call tab. No network calls. */

const $ = (id) => document.getElementById(id);
const state = { enabled: true, sensitivity: 62, duration: 1.8, direction: "right", sound: true };

function paint() {
  $("enabled").setAttribute("aria-checked", String(state.enabled));
  $("sensitivity").value = state.sensitivity;
  $("sensitivity-out").textContent = String(state.sensitivity);
  $("duration").value = state.duration;
  $("duration-out").textContent = `${Number(state.duration).toFixed(1)} s`;
  $("sound").checked = state.sound;
  document.querySelectorAll("#direction button").forEach((b) => {
    const on = b.dataset.dir === state.direction;
    b.classList.toggle("on", on);
    b.setAttribute("aria-checked", String(on));
  });
  const disabled = !state.enabled;
  ["snap", "sensitivity", "duration", "sound"].forEach((id) => ($(id).disabled = disabled));
  document.querySelectorAll("#direction button").forEach((b) => (b.disabled = disabled));
}

async function persist() {
  await chrome.storage.sync.set(state);
  chrome.runtime.sendMessage({ type: "SETTINGS_CHANGED", payload: state });
}

chrome.storage.sync.get(null).then((stored) => {
  Object.assign(state, stored);
  paint();
});

chrome.runtime.sendMessage({ type: "GET_STATE" }, (res) => {
  if (chrome.runtime.lastError || !res) return;
  if (res.host) $("host").textContent = res.host;
  if (typeof res.muted === "boolean") {
    $("mic-dot").classList.toggle("muted", res.muted);
    $("mic-label").textContent = res.muted ? "Microphone muted" : "Microphone live";
  }
});

$("enabled").addEventListener("click", () => {
  state.enabled = !state.enabled;
  paint();
  persist();
});

$("snap").addEventListener("click", () => chrome.runtime.sendMessage({ type: "SNAP_NOW" }));

["sensitivity", "duration"].forEach((id) =>
  $(id).addEventListener("input", (e) => {
    state[id] = Number(e.target.value);
    paint();
    persist();
  }),
);

document.querySelectorAll("#direction button").forEach((b) =>
  b.addEventListener("click", () => {
    state.direction = b.dataset.dir;
    paint();
    persist();
  }),
);

$("sound").addEventListener("change", (e) => {
  state.sound = e.target.checked;
  persist();
});
