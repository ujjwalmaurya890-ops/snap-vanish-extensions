import SnapMark from "./SnapMark";
import type { Direction } from "../lib/dust";
import type { SnapStatus } from "./SnapStage";

export type Settings = {
  enabled: boolean;
  sensitivity: number;
  duration: number;
  direction: Direction;
  sound: boolean;
};

type Props = {
  settings: Settings;
  onChange: (patch: Partial<Settings>) => void;
  onSnap: () => void;
  status: SnapStatus;
};

const DIRECTIONS: { id: Direction; glyph: string; name: string }[] = [
  { id: "left", glyph: "←", name: "Left" },
  { id: "up", glyph: "↑", name: "Up" },
  { id: "right", glyph: "→", name: "Right" },
  { id: "down", glyph: "↓", name: "Down" },
  { id: "toward", glyph: "◎", name: "Camera" },
];

export default function VanishPopup({ settings, onChange, onSnap, status }: Props) {
  const micMuted = status === "vanishing" || status === "gone";

  return (
    <div className="w-[360px] select-none overflow-hidden rounded-[14px] border border-black/10 bg-white font-sans text-[#1f1f1f] shadow-[0_30px_60px_-20px_rgba(25,21,16,0.55),0_10px_18px_-10px_rgba(25,21,16,0.35)]">
      {/* header */}
      <div className="flex items-center gap-3 border-b border-black/10 px-4 py-3.5">
        <span className="flex h-8 w-8 items-center justify-center rounded-[7px] bg-[#191510] text-white">
          <SnapMark className="h-[19px] w-[19px]" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="truncate text-[13.5px] font-semibold tracking-[-0.01em]">Snap Vanish</div>
          <div className="truncate text-[11px] text-[#5f5f5f]">
            meet.google.com · this tab only
          </div>
        </div>
        <Toggle
          on={settings.enabled}
          onChange={(v) => onChange({ enabled: v })}
          label="Master switch"
        />
      </div>

      {/* primary action */}
      <div className="px-4 pt-4">
        <button
          onClick={onSnap}
          disabled={!settings.enabled}
          className="flex w-full items-center justify-center gap-2 rounded-[8px] bg-[#d2451e] px-4 py-3 text-[13px] font-semibold text-white transition-colors hover:bg-[#e2522a] disabled:cursor-not-allowed disabled:bg-[#c9c2b8]"
        >
          <SnapMark className="h-4 w-4" />
          {status === "gone" ? "Snap to return" : "Snap now"}
        </button>
        <div className="mt-2.5 flex items-center justify-between px-0.5">
          <span className="text-[11px] text-[#5f5f5f]">Keyboard backup</span>
          <span className="rounded-[5px] border border-black/12 bg-[#f4f2ef] px-2 py-[3px] text-[10.5px] font-medium tracking-[0.08em] text-[#3b3b3b]">
            ALT + SHIFT + S
          </span>
        </div>
      </div>

      <div className="mx-4 my-4 h-px bg-black/10" />

      {/* sliders */}
      <div className="space-y-5 px-4">
        <Slider
          label="Snap sensitivity"
          display={`${settings.sensitivity}`}
          min={0}
          max={100}
          value={settings.sensitivity}
          onChange={(v) => onChange({ sensitivity: v })}
          disabled={!settings.enabled}
          caption="Higher = stricter trigger"
        />
        <Slider
          label="Dust duration"
          display={`${settings.duration.toFixed(1)} s`}
          min={0.5}
          max={4}
          step={0.1}
          value={settings.duration}
          onChange={(v) => onChange({ duration: v })}
          disabled={!settings.enabled}
          caption="Blow-away + reassembly"
        />
      </div>

      {/* direction */}
      <div className="px-4 pt-5">
        <div className="mb-2 text-[11.5px] font-medium text-[#3b3b3b]">Dust direction</div>
        <div className="grid grid-cols-5 overflow-hidden rounded-[8px] border border-black/12">
          {DIRECTIONS.map((d) => {
            const active = settings.direction === d.id;
            return (
              <button
                key={d.id}
                onClick={() => onChange({ direction: d.id })}
                disabled={!settings.enabled}
                title={d.name}
                className={`flex flex-col items-center gap-1 border-r border-black/10 py-2.5 text-[11px] transition-colors last:border-r-0 disabled:opacity-45 ${
                  active
                    ? "bg-[#191510] text-white"
                    : "bg-white text-[#4a4a4a] hover:bg-[#f4f2ef]"
                }`}
              >
                <span className="text-[15px] leading-none">{d.glyph}</span>
                <span className="text-[9.5px] tracking-[0.04em]">{d.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* status */}
      <div className="mt-4 flex items-center justify-between bg-[#f4f2ef] px-4 py-3">
        <div className="flex items-center gap-2">
          <span
            className={`h-[7px] w-[7px] rounded-full ${micMuted ? "bg-[#d2451e]" : "bg-[#2e9e4f]"}`}
          />
          <span className="text-[11.5px] text-[#3b3b3b]">
            {micMuted ? "Microphone muted" : "Microphone live"}
          </span>
        </div>
        <span className="text-[10.5px] tracking-[0.12em] text-[#7a7a7a]">0 B EGRESS</span>
      </div>

      <label className="flex cursor-pointer items-center gap-2.5 border-t border-black/10 px-4 py-3">
        <input
          type="checkbox"
          checked={settings.sound}
          onChange={(e) => onChange({ sound: e.target.checked })}
          className="h-[15px] w-[15px] accent-[#d2451e]"
        />
        <span className="text-[11.5px] text-[#3b3b3b]">
          Play the snap click (sound is used as confirmation only)
        </span>
      </label>
    </div>
  );
}

function Toggle({
  on,
  onChange,
  label,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className={`relative h-[22px] w-[38px] shrink-0 rounded-full transition-colors ${
        on ? "bg-[#d2451e]" : "bg-[#c9c2b8]"
      }`}
    >
      <span
        className={`absolute top-[3px] h-4 w-4 rounded-full bg-white shadow transition-all ${
          on ? "left-[19px]" : "left-[3px]"
        }`}
      />
    </button>
  );
}

function Slider({
  label,
  display,
  min,
  max,
  step = 1,
  value,
  onChange,
  disabled,
  caption,
}: {
  label: string;
  display: string;
  min: number;
  max: number;
  step?: number;
  value: number;
  onChange: (v: number) => void;
  disabled?: boolean;
  caption: string;
}) {
  return (
    <div className={disabled ? "opacity-45" : ""}>
      <div className="flex items-baseline justify-between">
        <span className="text-[11.5px] font-medium text-[#3b3b3b]">{label}</span>
        <span className="text-[11.5px] font-semibold tabular-nums text-[#d2451e]">{display}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        disabled={disabled}
        aria-label={label}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1"
      />
      <div className="text-[10px] tracking-[0.04em] text-[#8a8a8a]">{caption}</div>
    </div>
  );
}
