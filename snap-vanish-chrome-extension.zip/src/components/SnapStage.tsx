import { useCallback, useEffect, useRef, useState } from "react";
import { DustScene, playSnap, type Direction } from "../lib/dust";
import roomSrc from "../assets/room-empty.jpg";
import personSrc from "../assets/feed-person.jpg";

export type SnapStatus = "idle" | "vanishing" | "gone" | "returning";

type Props = {
  enabled: boolean;
  duration: number;
  direction: Direction;
  sensitivity: number;
  snapSignal: number;
  sound: boolean;
  onStatus: (s: SnapStatus) => void;
};

const STATUS_COPY: Record<SnapStatus, { label: string; tone: string }> = {
  idle: { label: "TALENT PRESENT · MIC LIVE", tone: "text-paper/70" },
  vanishing: { label: "DISINTEGRATING · MIC MUTED", tone: "text-[#F0623A]" },
  gone: { label: "FRAME EMPTY · MIC MUTED", tone: "text-paper/70" },
  returning: { label: "RECONSTRUCTING · MIC OPENING", tone: "text-[#F0623A]" },
};

export default function SnapStage({
  enabled,
  duration,
  direction,
  sensitivity,
  snapSignal,
  sound,
  onStatus,
}: Props) {
  const enabledRef = useRef(enabled);
  enabledRef.current = enabled;
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const tcRef = useRef<HTMLSpanElement>(null);
  const sceneRef = useRef<DustScene | null>(null);
  const phaseRef = useRef<{ p: SnapStatus; t0: number; from: number; to: number }>({
    p: "idle",
    t0: 0,
    from: 0,
    to: 0,
  });
  const settingsRef = useRef({ duration, direction });
  const soundRef = useRef(sound);
  const audioRef = useRef<AudioContext | null>(null);
  const [ready, setReady] = useState(false);
  const [status, setStatus] = useState<SnapStatus>("idle");
  const [count, setCount] = useState(0);

  settingsRef.current = { duration, direction };
  soundRef.current = sound;

  useEffect(() => {
    let cancelled = false;
    const scene = new DustScene();
    sceneRef.current = scene;

    const load = (src: string) =>
      new Promise<HTMLImageElement | null>((resolve) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = () => resolve(null);
        img.src = src;
      });

    Promise.all([load(roomSrc), load(personSrc)]).then(
      ([room, person]) => {
        if (cancelled) return;
        scene.build(room, person);
        setCount(scene.particleCount);
        setReady(true);
      },
    );

    return () => {
      cancelled = true;
    };
  }, []);

  // main render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let t = 0;
    const start = performance.now();

    const loop = () => {
      raf = requestAnimationFrame(loop);
      const ph = phaseRef.current;
      const now = performance.now();
      const dur = Math.max(0.35, settingsRef.current.duration) * 1000;

      if (ph.p === "vanishing" || ph.p === "returning") {
        const k = Math.min(1, (now - ph.t0) / dur);
        t = ph.from + (ph.to - ph.from) * k;
        if (k >= 1) {
          const next: SnapStatus = ph.p === "vanishing" ? "gone" : "idle";
          phaseRef.current = { p: next, t0: now, from: ph.to, to: ph.to };
          setStatus(next);
          onStatus(next);
        }
      } else {
        t = phaseRef.current.to;
      }

      sceneRef.current?.render(
        ctx,
        t,
        settingsRef.current.direction,
        settingsRef.current.duration,
      );

      if (tcRef.current) {
        const el = (now - start) / 1000;
        const mm = String(Math.floor(el / 60)).padStart(2, "0");
        const ss = String(Math.floor(el % 60)).padStart(2, "0");
        const ff = String(Math.floor((el % 1) * 25)).padStart(2, "0");
        tcRef.current.textContent = `00:${mm}:${ss}:${ff}`;
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [ready, onStatus]);

  const fire = useCallback(() => {
    const ph = phaseRef.current;
    if (!enabledRef.current) return;
    if (ph.p === "vanishing" || ph.p === "returning") return;
    const next: SnapStatus = ph.p === "gone" ? "returning" : "vanishing";
    phaseRef.current = {
      p: next,
      t0: performance.now(),
      from: next === "vanishing" ? 0 : 1,
      to: next === "vanishing" ? 1 : 0,
    };
    setStatus(next);
    onStatus(next);
    if (soundRef.current) {
      try {
        if (!audioRef.current) {
          const AC =
            window.AudioContext ||
            (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
          audioRef.current = new AC();
        }
        if (audioRef.current.state === "suspended") void audioRef.current.resume();
        playSnap(audioRef.current);
      } catch {
        /* audio is a garnish, never a dependency */
      }
    }
  }, [onStatus]);

  // backup keyboard shortcut
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.altKey && e.shiftKey && e.code === "KeyS") {
        e.preventDefault();
        fire();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [fire]);

  useEffect(() => {
    if (snapSignal > 0) fire();
  }, [snapSignal, fire]);

  const statusCopy = STATUS_COPY[status];

  return (
    <div>
      {/* the frame: pasted photographic print */}
      <div className="relative bg-frame tipped">
        <div className="flex items-center justify-between border-b border-white/10 px-4 py-2.5">
          <div className="flex items-center gap-3">
            <span className="flex h-2 w-2 rounded-full bg-[#F0623A] shadow-[0_0_10px_#F0623A]" />
            <span className="rail text-paper/55">CAM 01 · 1280×720 · 25 FPS</span>
          </div>
          <span ref={tcRef} className="rail tnum text-paper/55">
            00:00:00:00
          </span>
        </div>

        <div className="relative">
          <canvas
            ref={canvasRef}
            width={1280}
            height={720}
            className="block w-full"
            style={{ aspectRatio: "16 / 9" }}
            aria-label="Live camera preview showing the Snap Vanish disintegration effect"
          />

          {!ready && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-frame">
              <div className="h-[2px] w-40 overflow-hidden bg-white/15">
                <div className="h-full w-1/3 animate-pulse bg-[#F0623A]" />
              </div>
              <span className="rail text-paper/50">CALIBRATING MATTE…</span>
            </div>
          )}

          {/* corner crop marks */}
          <div className="pointer-events-none absolute inset-0">
            {[
              "left-3 top-3 border-l border-t",
              "right-3 top-3 border-r border-t",
              "left-3 bottom-3 border-l border-b",
              "right-3 bottom-3 border-r border-b",
            ].map((c) => (
              <span key={c} className={`absolute h-5 w-5 border-white/25 ${c}`} />
            ))}
          </div>

          {/* live readout */}
          <div className="pointer-events-none absolute bottom-4 left-4 flex items-center gap-2.5">
            <span
              className={`rail bg-black/55 px-2.5 py-1.5 backdrop-blur-sm ${statusCopy.tone}`}
            >
              {statusCopy.label}
            </span>
          </div>
          <div className="pointer-events-none absolute right-4 top-4 text-right">
            <div className="rail text-[#F0623A]">EGRESS 0 B</div>
            <div className="rail tnum text-paper/45">
              {(count ? count.toLocaleString() : "—")} PARTICLES
            </div>
          </div>
        </div>

        {/* transport */}
        <div className="flex flex-wrap items-center gap-3 border-t border-white/10 px-4 py-3.5">
          <button
            onClick={fire}
            disabled={!enabled}
            className={`px-6 py-3 font-mono text-[11px] font-semibold uppercase tracking-[0.18em] transition-colors ${
              enabled
                ? "bg-[#F0623A] text-[#1a0d07] hover:bg-[#ff7a4d]"
                : "cursor-not-allowed bg-white/10 text-paper/40"
            }`}
          >
            {!enabled
              ? "Extension is off"
              : status === "gone"
                ? "Snap to return"
                : status === "idle"
                  ? "Snap now"
                  : "Working…"}
          </button>
          <button
            onClick={() => {
              phaseRef.current = { p: "idle", t0: 0, from: 0, to: 0 };
              setStatus("idle");
              onStatus("idle");
            }}
            className="border border-white/15 px-5 py-3 font-mono text-[11px] uppercase tracking-[0.18em] text-paper/70 transition-colors hover:border-white/35 hover:text-paper"
          >
            Reset
          </button>
          <div className="ml-auto flex items-center gap-2">
            <span className="rail text-paper/40">KEYBOARD BACKUP</span>
            <kbd className="rail border border-white/20 bg-white/5 px-2.5 py-1.5 text-paper/80">
              ALT + SHIFT + S
            </kbd>
          </div>
        </div>
      </div>

      {/* controls, set on the paper below the print */}
      <div className="mt-7 grid grid-cols-1 gap-x-10 gap-y-6 sm:grid-cols-2">
        <Control
          name="Dust duration"
          value={`${duration.toFixed(1)} s`}
          hint="How long the disintegration and the drift take to complete. Set it from the popup below — it takes effect on the next snap."
        >
          <div className="h-[3px] w-full bg-rule">
            <div
              className="h-full bg-ember"
              style={{ width: `${((duration - 0.5) / 3.5) * 100}%` }}
            />
          </div>
        </Control>
        <Control
          name="Trigger sensitivity"
          value={`${sensitivity}`}
          hint="Snap detection threshold — higher is stricter, so waving, typing and reaching for a mug stop counting as snaps."
        >
          <div className="h-[3px] w-full bg-rule">
            <div className="h-full bg-ember" style={{ width: `${sensitivity}%` }} />
          </div>
        </Control>
      </div>
    </div>
  );
}

function Control({
  name,
  value,
  hint,
  children,
}: {
  name: string;
  value: string;
  hint: string;
  children?: React.ReactNode;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <span className="label text-ink">{name}</span>
        <span className="tnum font-mono text-[13px] text-ember">{value}</span>
      </div>
      <div className="mt-2">{children}</div>
      <p className="mt-2 max-w-[38ch] text-[12.5px] leading-[1.6] text-ink-soft">{hint}</p>
    </div>
  );
}
