import { useCallback, useState } from "react";
import SnapStage, { type SnapStatus } from "./components/SnapStage";
import VanishPopup, { type Settings } from "./components/VanishPopup";
import {
  Footer,
  Header,
  Hero,
  Install,
  Pipeline,
  PrivacyBand,
  Rail,
  Reveal,
} from "./components/Sections";

export default function App() {
  const [settings, setSettings] = useState<Settings>({
    enabled: true,
    sensitivity: 62,
    duration: 1.8,
    direction: "right",
    sound: true,
  });
  const [snapSignal, setSnapSignal] = useState(0);
  const [status, setStatus] = useState<SnapStatus>("idle");

  const onStatus = useCallback((s: SnapStatus) => setStatus(s), []);
  const onChange = useCallback(
    (patch: Partial<Settings>) => setSettings((prev) => ({ ...prev, ...patch })),
    [],
  );
  const onSnap = useCallback(() => setSnapSignal((n) => n + 1), []);

  return (
    <div className="relative min-h-screen bg-paper">
      <div className="grain" aria-hidden />

      <Header />
      <Hero />

      {/* ---------------------------------------------------------- demo */}
      <section id="demo" className="border-b border-rule bg-paper-2/55">
        <div className="mx-auto grid max-w-[1280px] grid-cols-1 gap-x-10 px-6 py-16 md:grid-cols-[180px_1fr] md:px-10 md:py-24">
          <Rail>
            <div className="text-ember">LIVE DEMO</div>
            <div>FRAME 001–025</div>
            <div className="tnum">WEBGL2 · 60 FPS</div>
            <div className="mt-6 h-px w-10 bg-rule" />
            <div className="leading-[1.9]">
              NOT A VIDEO
              <br />
              REAL PARTICLES
              <br />
              REVERSIBLE
            </div>
          </Rail>

          <div>
            <h2 className="max-w-[15ch] font-display text-[clamp(2.5rem,6vw,5rem)] leading-[0.92] tracking-[-0.022em]">
              Press snap and watch the room come back.
            </h2>
            <p className="mt-6 max-w-[56ch] text-[16px] leading-[1.62] text-ink-2">
              This is the actual dust engine from the extension, running on the plate it would
              composite behind you. Fire it with the button, the popup, or{" "}
              <span className="whitespace-nowrap font-mono text-[13px] text-ember">
                ALT + SHIFT + S
              </span>{" "}
              on your keyboard. Then fire it again — the same particles run backwards and put you
              back in the chair.
            </p>

            <div className="mt-11 grid grid-cols-1 gap-x-12 gap-y-12 xl:grid-cols-[1fr_360px]">
              <div>
                <SnapStage
                  enabled={settings.enabled}
                  duration={settings.duration}
                  direction={settings.direction}
                  sensitivity={settings.sensitivity}
                  sound={settings.sound}
                  snapSignal={snapSignal}
                  onStatus={onStatus}
                />

                <div className="mt-8 grid grid-cols-2 gap-x-8 gap-y-6 sm:grid-cols-4">
                  {[
                    ["Latency", "41 ms"],
                    ["Matte", "25 fps"],
                    ["False triggers", "0 / 6 h"],
                    ["Egress", "0 B"],
                  ].map(([k, v]) => (
                    <div key={k} className="border-t border-rule pt-3">
                      <div className="rail text-ink-soft">{k}</div>
                      <div className="tnum mt-1 font-display text-[27px] leading-none">{v}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* the popup, tipped onto the sheet like a printed screenshot */}
              <Reveal delay={0.1}>
                <div id="popup" className="xl:sticky xl:top-24">
                  <div className="rail mb-4 text-ink-soft">
                    FIG. 02 — EXTENSION POPUP, 360 PX
                  </div>
                  <div className="origin-top-left rotate-[-1.1deg] transition-transform duration-500 hover:rotate-0">
                    <VanishPopup
                      settings={settings}
                      onChange={onChange}
                      onSnap={onSnap}
                      status={status}
                    />
                  </div>
                  <p className="mt-8 max-w-[38ch] text-[13px] leading-[1.66] text-ink-2">
                    Everything here is live. Sensitivity, duration and direction are wired straight
                    into the frame on the left — change the direction to{" "}
                    <span className="text-ember">Camera</span> and the dust expands past the lens
                    instead of blowing sideways.
                  </p>
                </div>
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      <Pipeline />
      <PrivacyBand />
      <Install />
      <Footer />
    </div>
  );
}
