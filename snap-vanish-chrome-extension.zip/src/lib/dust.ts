/**
 * Snap Vanish — dust engine.
 *
 * The person layer is eroded by a stack of pre-rendered soft-blob masks
 * (one per dissolving stage), while ~22k particles sampled from the person's
 * own pixels are advected along an analytic path. Analytic motion means the
 * whole thing can be evaluated at any t — which is why the snap can run
 * *backwards* and reassemble the person exactly.
 */

export type Direction = "left" | "right" | "up" | "down" | "toward";

export const FRAME_W = 1280;
export const FRAME_H = 720;

const STAGES = 20;
const ERODE_SCALE = 0.5;

type Particle = {
  x: number;
  y: number;
  delay: number;
  seed: number;
  size: number;
  power: number;
  r: number;
  g: number;
  b: number;
};

export type SceneStatus = "loading" | "ready" | "fallback";

function makeCanvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return c;
}

function drawCover(
  ctx: CanvasRenderingContext2D,
  img: CanvasImageSource,
  iw: number,
  ih: number,
  w: number,
  h: number,
) {
  const s = Math.max(w / iw, h / ih);
  const dw = iw * s;
  const dh = ih * s;
  ctx.drawImage(img, (w - dw) / 2, (h - dh) / 2, dw, dh);
}

/** Generous seated-figure silhouette: head, neck, shoulders, torso, raised arm. */
function silhouette(ctx: CanvasRenderingContext2D, w: number, h: number) {
  const X = (n: number) => n * w;
  const Y = (n: number) => n * h;

  ctx.beginPath();
  // head
  ctx.ellipse(X(0.5), Y(0.285), X(0.115), Y(0.168), 0, 0, Math.PI * 2);
  ctx.fill();
  // neck + shoulders + torso, generously oversized
  ctx.beginPath();
  ctx.moveTo(X(0.215), Y(1.08));
  ctx.lineTo(X(0.232), Y(0.62));
  ctx.quadraticCurveTo(X(0.25), Y(0.452), X(0.392), Y(0.418));
  ctx.lineTo(X(0.432), Y(0.406));
  ctx.quadraticCurveTo(X(0.5), Y(0.378), X(0.568), Y(0.406));
  ctx.lineTo(X(0.608), Y(0.418));
  ctx.quadraticCurveTo(X(0.75), Y(0.452), X(0.768), Y(0.62));
  ctx.lineTo(X(0.785), Y(1.08));
  ctx.closePath();
  ctx.fill();
  // arms: one resting, one raised (the snapping hand)
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = "#000";
  ctx.lineWidth = X(0.135);
  ctx.beginPath();
  ctx.moveTo(X(0.325), Y(0.58));
  ctx.quadraticCurveTo(X(0.242), Y(0.82), X(0.318), Y(1.02));
  ctx.stroke();
  ctx.lineWidth = X(0.125);
  ctx.beginPath();
  ctx.moveTo(X(0.675), Y(0.58));
  ctx.quadraticCurveTo(X(0.775), Y(0.6), X(0.788), Y(0.408));
  ctx.stroke();
  // hand
  ctx.beginPath();
  ctx.ellipse(X(0.795), Y(0.362), X(0.072), Y(0.095), -0.25, 0, Math.PI * 2);
  ctx.fill();
}

function windFor(dir: Direction): { x: number; y: number } {
  switch (dir) {
    case "left":
      return { x: -1, y: -0.16 };
    case "right":
      return { x: 1, y: -0.12 };
    case "up":
      return { x: 0.06, y: -1.25 };
    case "down":
      return { x: 0.04, y: 1.15 };
    case "toward":
    default:
      return { x: 0, y: 0 };
  }
}

export class DustScene {
  readonly w = FRAME_W;
  readonly h = FRAME_H;
  status: SceneStatus = "loading";

  private room = makeCanvas(FRAME_W, FRAME_H);
  private person = makeCanvas(FRAME_W, FRAME_H);
  private scratch = makeCanvas(FRAME_W, FRAME_H);
  private erode: HTMLCanvasElement[] = [];
  private particles: Particle[] = [];
  private blob = makeCanvas(64, 64);

  constructor() {
    // soft round sprite used to stamp the erosion masks
    const b = this.blob.getContext("2d")!;
    const g = b.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, "rgba(0,0,0,1)");
    g.addColorStop(0.55, "rgba(0,0,0,0.75)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    b.fillStyle = g;
    b.fillRect(0, 0, 64, 64);
  }

  /** Build from bitmaps; falls back to procedural art if an image is missing. */
  build(roomImg: HTMLImageElement | null, personImg: HTMLImageElement | null) {
    const { w, h } = this;
    const roomCtx = this.room.getContext("2d")!;
    const perCtx = this.person.getContext("2d")!;

    if (roomImg && personImg && roomImg.naturalWidth && personImg.naturalWidth) {
      drawCover(roomCtx, roomImg, roomImg.naturalWidth, roomImg.naturalHeight, w, h);
      drawCover(perCtx, personImg, personImg.naturalWidth, personImg.naturalHeight, w, h);
      this.status = "ready";
    } else {
      this.paintFallbackRoom(roomCtx);
      this.paintFallbackPerson(perCtx);
      this.status = "fallback";
    }

    // soft alpha mask for the figure
    const mask = makeCanvas(w, h);
    const mctx = mask.getContext("2d")!;
    mctx.fillStyle = "#000";
    mctx.strokeStyle = "#000";
    mctx.filter = "blur(19px)";
    silhouette(mctx, w, h);
    mctx.filter = "none";

    perCtx.globalCompositeOperation = "destination-in";
    perCtx.drawImage(mask, 0, 0);
    perCtx.globalCompositeOperation = "source-over";

    // ---- sample particles from the figure's own pixels -----------------
    const mdata = mctx.getImageData(0, 0, w, h).data;
    const pdata = perCtx.getImageData(0, 0, w, h).data;
    const step = 3;
    const found: Particle[] = [];
    for (let y = 0; y < h; y += step) {
      for (let x = 0; x < w; x += step) {
        const i = (y * w + x) * 4;
        if (mdata[i + 3] < 110) continue;
        const a = pdata[i + 3];
        if (a < 40) continue;
        found.push({
          x,
          y,
          delay: 0,
          seed: Math.random(),
          size: 1.4 + Math.random() * 2.2,
          power: 0.55 + Math.random() * 0.9,
          r: pdata[i],
          g: pdata[i + 1],
          b: pdata[i + 2],
        });
      }
    }

    // dissolve spreads outward from the raised hand
    const ox = 0.795 * w;
    const oy = 0.4 * h;
    let maxD = 1;
    for (const p of found) {
      const d = Math.hypot(p.x - ox, p.y - oy);
      maxD = Math.max(maxD, d);
    }
    for (const p of found) {
      const d = Math.hypot(p.x - ox, p.y - oy) / maxD;
      p.delay = Math.min(0.86, d * 0.62 + p.seed * 0.26);
    }

    // keep the run light enough for 60fps on integrated graphics
    const MAX = 22000;
    if (found.length > MAX) {
      for (let i = found.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [found[i], found[j]] = [found[j], found[i]];
      }
      found.length = MAX;
    }
    this.particles = found;

    // ---- pre-render the erosion stages --------------------------------
    this.erode = [];
    const ew = Math.round(w * ERODE_SCALE);
    const eh = Math.round(h * ERODE_SCALE);
    const acc = makeCanvas(ew, eh);
    const accCtx = acc.getContext("2d")!;
    for (let s = 0; s < STAGES; s++) {
      const threshold = (s + 1) / STAGES;
      for (const p of this.particles) {
        if (p.delay < threshold && p.delay >= threshold - 1 / STAGES) {
          const r = (7 + p.size * 4.6) * ERODE_SCALE * (1.15 + p.seed * 0.5);
          accCtx.globalAlpha = 0.85;
          accCtx.drawImage(this.blob, p.x * ERODE_SCALE - r, p.y * ERODE_SCALE - r, r * 2, r * 2);
        }
      }
      accCtx.globalAlpha = 1;
      const stage = makeCanvas(ew, eh);
      stage.getContext("2d")!.drawImage(acc, 0, 0);
      this.erode.push(stage);
    }
  }

  get particleCount() {
    return this.particles.length;
  }

  /** t = 0 → person whole, t = 1 → fully dust. Safe to run in either direction. */
  render(ctx: CanvasRenderingContext2D, t: number, dir: Direction, duration: number) {
    const { w, h } = this;
    const tt = Math.max(0, Math.min(1, t));
    ctx.clearRect(0, 0, w, h);
    ctx.drawImage(this.room, 0, 0);

    // eroded person layer
    if (tt < 0.995) {
      const idx = Math.min(STAGES - 1, Math.floor(tt * STAGES));
      const sctx = this.scratch.getContext("2d")!;
      sctx.globalCompositeOperation = "source-over";
      sctx.clearRect(0, 0, w, h);
      sctx.drawImage(this.person, 0, 0);
      if (tt > 0.002 && this.erode[idx]) {
        sctx.globalCompositeOperation = "destination-out";
        sctx.drawImage(this.erode[idx], 0, 0, w, h);
        sctx.globalCompositeOperation = "source-over";
      }
      ctx.drawImage(this.scratch, 0, 0);
    }

    // dust
    const wind = windFor(dir);
    const spread = 620 * (duration / 1.8) ** 0.45;
    for (const p of this.particles) {
      if (tt <= p.delay) continue;
      const local = Math.min(1, (tt - p.delay) / (1 - p.delay + 0.0001));
      const e = Math.pow(local, 1.22);
      const nx = p.x - w / 2;
      const ny = p.y - h / 2;

      let dx: number;
      let dy: number;
      if (dir === "toward") {
        const k = 1 + e * 1.35;
        dx = nx * (k - 1) + Math.sin(p.seed * 9.1 + local * 3.4) * 30 * e;
        dy = ny * (k - 1) + Math.cos(p.seed * 7.7 + local * 2.8) * 22 * e;
      } else {
        dx = wind.x * e * spread * p.power + Math.sin(p.seed * 9.1 + local * 3.4 + p.y * 0.012) * 34 * e;
        dy = wind.y * e * spread * p.power + e * e * 150 * (dir === "up" ? -0.2 : 1)
          + Math.cos(p.seed * 7.7 + local * 2.8 + p.x * 0.01) * 24 * e;
      }

      const x = p.x + dx;
      const y = p.y + dy;
      let alpha = Math.pow(1 - local, 1.15);
      alpha *= Math.min(1, local * 16);
      if (alpha <= 0.012) continue;

      const size = p.size * (1 - local * 0.42);
      // ember flash while it is still hot, cooling to ash
      const heat = Math.max(0, 1 - local * 3.1);
      const r = Math.round(p.r + (255 - p.r) * heat * 0.85 + (196 - p.r) * (1 - heat) * 0.35);
      const g = Math.round(p.g + (122 - p.g) * heat * 0.85 + (185 - p.g) * (1 - heat) * 0.35);
      const b = Math.round(p.b + (51 - p.b) * heat * 0.85 + (172 - p.b) * (1 - heat) * 0.35);

      ctx.fillStyle = `rgba(${r},${g},${b},${alpha})`;
      ctx.fillRect(x, y, size, size);
      // short motion smear
      ctx.fillStyle = `rgba(${r},${g},${b},${alpha * 0.3})`;
      ctx.fillRect(x - dx * 0.055, y - dy * 0.055, size * 0.82, size * 0.82);
    }
  }

  // ---- procedural fallback so a missing asset never leaves a hole --------
  private paintFallbackRoom(ctx: CanvasRenderingContext2D) {
    const { w, h } = this;
    const g = ctx.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, "#c9b79c");
    g.addColorStop(0.55, "#a98f72");
    g.addColorStop(1, "#6d5741");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "rgba(255,236,205,0.22)";
    ctx.fillRect(0, 0, w * 0.32, h);
    ctx.fillStyle = "rgba(60,44,30,0.32)";
    ctx.fillRect(w * 0.72, h * 0.18, w * 0.22, h * 0.62);
    ctx.fillStyle = "rgba(38,28,19,0.5)";
    ctx.fillRect(0, h * 0.82, w, h * 0.18);
  }

  private paintFallbackPerson(ctx: CanvasRenderingContext2D) {
    const { w, h } = this;
    this.paintFallbackRoom(ctx);
    ctx.fillStyle = "#2c2620";
    ctx.beginPath();
    ctx.ellipse(w * 0.5, h * 0.3, w * 0.098, h * 0.142, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(w * 0.3, h * 1.05);
    ctx.quadraticCurveTo(w * 0.32, h * 0.5, w * 0.5, h * 0.46);
    ctx.quadraticCurveTo(w * 0.68, h * 0.5, w * 0.7, h * 1.05);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#5b4b3c";
    ctx.fillRect(w * 0.4, h * 0.52, w * 0.2, h * 0.53);
  }
}

/** A single synthesised snap click — band-passed noise burst. */
export function playSnap(ctx: AudioContext | null, gain = 0.32) {
  if (!ctx) return;
  const now = ctx.currentTime;
  const len = Math.floor(ctx.sampleRate * 0.055);
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) {
    const t = i / len;
    data[i] = (Math.random() * 2 - 1) * Math.pow(1 - t, 3.2) * (i < len * 0.06 ? i / (len * 0.06) : 1);
  }
  const src = ctx.createBufferSource();
  src.buffer = buf;
  const bp = ctx.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.value = 3400;
  bp.Q.value = 1.4;
  const g = ctx.createGain();
  g.gain.value = gain;
  src.connect(bp).connect(g).connect(ctx.destination);
  src.start(now);
}
